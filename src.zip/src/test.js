const mod = require('./index.js');

mod.handler('','', function(e){})